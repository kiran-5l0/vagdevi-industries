export type DivisionId = 'chemicals' | 'dehydrated' | 'dryfruits' | 'packaging';

export interface ProductAttribute {
  label: string;
  value: string;
}

export interface Product {
  id: string;
  name: string;
  divisionId: DivisionId;
  divisionName: string;
  category: string;
  tagline: string;
  description: string;
  formula?: string;
  casNumber?: string;
  purity?: string;
  grade?: string;
  meshSize?: string;
  moisture?: string;
  ashContent?: string;
  microbialStandard?: string;
  shelfLife?: string;
  origin?: string;
  countPerLb?: string;
  fluting?: string;
  burstingFactor?: string;
  gsm?: string;
  compressionStrength?: string;
  printing?: string;
  packagingOptions: string[];
  standardMoq: string;
  msdsAvailable?: boolean;
  coaAvailable?: boolean;
  specHighlights: ProductAttribute[];
  sampleSpecs?: {
    testParameter: string;
    specification: string;
    result: string;
  }[];
}

export interface Division {
  id: DivisionId;
  name: string;
  shortTitle: string;
  subtitle: string;
  modelReference: string;
  scope: string;
  image: string;
  accentColor: string;
  categories: string[];
  features: string[];
  stat: {
    value: string;
    label: string;
  };
}

export interface CartItem {
  product: Product;
  quantity: string;
  targetSpecs?: string;
}

export interface RFQSubmission {
  name: string;
  company: string;
  phone: string;
  email: string;
  location: string;
  pincode: string;
  division: string;
  divisions: string[];
  items: {
    productId: string;
    productName: string;
    divisionId: string;
    quantity: string;
    targetSpecs?: string;
  }[];
  message: string;
}
