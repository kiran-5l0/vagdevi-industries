import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCatalog } from './components/ProductCatalog';
import { ProductDetailModal } from './components/ProductDetailModal';
import { MultiProductRFQModal } from './components/MultiProductRFQModal';
import { WhyChooseUs } from './components/WhyChooseUs';
import { ComplianceTrustStrip } from './components/ComplianceTrustStrip';
import { ContactSection } from './components/ContactSection';
import { FloatingActions } from './components/FloatingActions';
import { Footer } from './components/Footer';
import { BrochureModal } from './components/BrochureModal';
import { CartItem, DivisionId, Product } from './types';
import { PRODUCTS } from './data/portalData';

export default function App() {
  // Navigation & Filtering State
  const [activeDivision, setActiveDivision] = useState<DivisionId | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Cart & RFQ State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isRFQModalOpen, setIsRFQModalOpen] = useState<boolean>(false);
  const [targetQuoteProduct, setTargetQuoteProduct] = useState<Product | null>(null);

  // Modals
  const [specProduct, setSpecProduct] = useState<Product | null>(null);
  const [isBrochureOpen, setIsBrochureOpen] = useState<boolean>(false);

  // Cart Handlers
  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        // If already in cart, remove it (toggle behavior)
        return prev.filter((item) => item.product.id !== product.id);
      }
      return [...prev, { product, quantity: product.standardMoq }];
    });
  };

  const handleRemoveCartItem = (productId: string) => {
    setCartItems((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const handleUpdateCartQuantity = (productId: string, quantity: string) => {
    setCartItems((prev) =>
      prev.map((item) =>
        item.product.id === productId ? { ...item, quantity } : item
      )
    );
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Launch RFQ modal for a specific single product
  const handleQuickQuoteForProduct = (product: Product) => {
    // Add product to cart if not present
    if (!cartItems.some((ci) => ci.product.id === product.id)) {
      setCartItems((prev) => [...prev, { product, quantity: product.standardMoq }]);
    }
    setTargetQuoteProduct(product);
    setIsRFQModalOpen(true);
  };

  // Launch RFQ modal for consolidated multi-product quote
  const handleOpenGeneralRFQ = () => {
    setTargetQuoteProduct(null);
    setIsRFQModalOpen(true);
  };

  const handleSelectDivision = (id: DivisionId | 'all') => {
    setActiveDivision(id);
    const catalogElem = document.getElementById('catalog-section');
    if (catalogElem) {
      catalogElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Enterprise Header */}
      <Header
        cartCount={cartItems.length}
        onOpenCart={handleOpenGeneralRFQ}
        onSelectDivision={handleSelectDivision}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onSelectDivision={(id) => handleSelectDivision(id)}
          onOpenRFQ={handleOpenGeneralRFQ}
        />

        {/* Integrated Product Catalog with Division Switching */}
        <ProductCatalog
          activeDivision={activeDivision}
          onSelectDivision={setActiveDivision}
          onSelectProductForSpecs={(prod) => setSpecProduct(prod)}
          onQuickQuoteForProduct={handleQuickQuoteForProduct}
          onAddToCart={handleAddToCart}
          cartProductIds={cartItems.map((ci) => ci.product.id)}
          searchQuery={searchQuery}
        />

        {/* Why Choose Us & Procurement FAQ */}
        <WhyChooseUs onOpenRFQ={handleOpenGeneralRFQ} />

        {/* Statutory Compliance & Quality Testing Strip */}
        <ComplianceTrustStrip />

        {/* Registered Office & Contact Sales Desk with Bachupally Google Map */}
        <ContactSection
          onOpenBrochure={() => setIsBrochureOpen(true)}
          onOpenRFQ={handleOpenGeneralRFQ}
        />
      </main>

      {/* Corporate Footer */}
      <Footer
        onSelectDivision={(id) => handleSelectDivision(id)}
        onOpenBrochure={() => setIsBrochureOpen(true)}
        onOpenRFQ={handleOpenGeneralRFQ}
      />

      {/* Floating Actions (WhatsApp & Call Us) */}
      <FloatingActions
        cartCount={cartItems.length}
        onOpenCart={handleOpenGeneralRFQ}
      />

      {/* Product Technical Specifications & Batch COA Modal */}
      <ProductDetailModal
        product={specProduct}
        onClose={() => setSpecProduct(null)}
        onAddToRFQ={handleAddToCart}
        isInCart={cartItems.some((ci) => ci.product.id === specProduct?.id)}
        onQuickQuote={handleQuickQuoteForProduct}
      />

      {/* Multi-Product RFQ Submission Modal */}
      <MultiProductRFQModal
        isOpen={isRFQModalOpen}
        onClose={() => {
          setIsRFQModalOpen(false);
          setTargetQuoteProduct(null);
        }}
        cartItems={cartItems}
        onRemoveItem={handleRemoveCartItem}
        onUpdateQuantity={handleUpdateCartQuantity}
        onClearCart={handleClearCart}
        initialProduct={targetQuoteProduct}
      />

      {/* Unified Enterprise Brochure Modal */}
      <BrochureModal
        isOpen={isBrochureOpen}
        onClose={() => setIsBrochureOpen(false)}
      />
    </div>
  );
}
