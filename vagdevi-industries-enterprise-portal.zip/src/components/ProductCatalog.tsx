import React, { useState } from 'react';
import {
  FileText,
  Plus,
  Check,
  Send,
  Download,
  Info,
  Layers,
  Sparkles,
  PackageCheck,
  FileCheck2,
} from 'lucide-react';
import { DIVISIONS, PRODUCTS, COMPANY_PROFILE } from '../data/portalData';
import { DivisionId, Product } from '../types';

interface ProductCatalogProps {
  activeDivision: DivisionId | 'all';
  onSelectDivision: (id: DivisionId | 'all') => void;
  onSelectProductForSpecs: (product: Product) => void;
  onQuickQuoteForProduct: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  cartProductIds: string[];
  searchQuery: string;
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  activeDivision,
  onSelectDivision,
  onSelectProductForSpecs,
  onQuickQuoteForProduct,
  onAddToCart,
  cartProductIds,
  searchQuery,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Filter products by division, category, and search query
  const filteredProducts = PRODUCTS.filter((item) => {
    // Division filter
    if (activeDivision !== 'all' && item.divisionId !== activeDivision) {
      return false;
    }
    // Category filter
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }
    // Search query filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchCategory = item.category.toLowerCase().includes(q);
      const matchDesc = item.description.toLowerCase().includes(q);
      const matchCas = item.casNumber?.toLowerCase().includes(q);
      const matchFormula = item.formula?.toLowerCase().includes(q);
      const matchMesh = item.meshSize?.toLowerCase().includes(q);
      const matchGrade = item.grade?.toLowerCase().includes(q);
      const matchBF = item.burstingFactor?.toLowerCase().includes(q);

      return matchName || matchCategory || matchDesc || matchCas || matchFormula || matchMesh || matchGrade || matchBF;
    }
    return true;
  });

  // Get active division metadata if specific division is selected
  const currentDivisionMeta = DIVISIONS.find((d) => d.id === activeDivision);

  // Available categories for current view
  const availableCategories = activeDivision === 'all'
    ? Array.from(new Set(PRODUCTS.map((p) => p.category)))
    : currentDivisionMeta?.categories || [];

  return (
    <section id="catalog-section" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="text-xs font-semibold text-blue-700 tracking-wider uppercase mb-2">
            Integrated Enterprise Catalog
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight [text-wrap:balance]">
            Standardized Industrial Products & Technical Specifications
          </h2>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            Browse our laboratory-certified chemicals, dehydrated ingredients, graded dry fruits, and heavy-duty corrugated cartons. Request single or consolidated multi-product quotations.
          </p>
        </div>

        {/* Division Tab Switcher (Functional Segmented Button Bar) */}
        <div className="mt-8 flex items-center justify-center">
          <div className="flex flex-wrap items-center justify-center gap-1.5 p-1.5 bg-slate-200/80 rounded-xl max-w-full">
            <button
              onClick={() => {
                onSelectDivision('all');
                setSelectedCategory('all');
              }}
              className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                activeDivision === 'all'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
              }`}
            >
              All 4 Divisions
            </button>

            {DIVISIONS.map((div) => {
              const isActive = activeDivision === div.id;
              return (
                <button
                  key={div.id}
                  onClick={() => {
                    onSelectDivision(div.id);
                    setSelectedCategory('all');
                  }}
                  className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
                  }`}
                >
                  {div.shortTitle}
                </button>
              );
            })}
          </div>
        </div>

        {/* Division Context Header if specific division active */}
        {currentDivisionMeta && (
          <div className="mt-6 p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <span className="font-semibold text-blue-700">{currentDivisionMeta.name}</span>
                <span aria-hidden="true">·</span>
                <span>{currentDivisionMeta.modelReference}</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-700 mt-1 max-w-3xl">
                {currentDivisionMeta.scope}
              </p>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs font-mono text-slate-600 bg-slate-100 px-2.5 py-1 rounded">
                MOQ: {currentDivisionMeta.stat.value}
              </span>
            </div>
          </div>
        )}

        {/* Category Sub-Filters */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <span className="text-xs font-medium text-slate-500 mr-1">Categories:</span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              selectedCategory === 'all'
                ? 'bg-slate-800 text-white'
                : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            All Categories ({filteredProducts.length})
          </button>
          {availableCategories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="mt-12 text-center py-12 bg-white rounded-xl border border-slate-200">
            <Info className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <h3 className="text-base font-semibold text-slate-800">No products match your filter</h3>
            <p className="text-xs text-slate-500 mt-1">Try resetting the category filter or search query</p>
            <button
              onClick={() => {
                onSelectDivision('all');
                setSelectedCategory('all');
              }}
              className="mt-4 px-4 py-2 text-xs font-semibold text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProducts.map((product) => {
              const inCart = cartProductIds.includes(product.id);

              // Pre-fill WhatsApp message for quick quote
              const waText = encodeURIComponent(
                `Hello Vagdevi Industries, I am requesting a formal quote for *${product.name}* (Division: ${product.divisionName}). MOQ/Estimated Requirement: ${product.standardMoq}. Please share commercial price and delivery lead time.`
              );
              const waUrl = `https://wa.me/${COMPANY_PROFILE.primaryPhoneRaw}?text=${waText}`;

              return (
                <div
                  key={product.id}
                  className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-slate-300 transition-all flex flex-col justify-between overflow-hidden"
                >
                  {/* Card Header & Metadata */}
                  <div className="p-5">
                    <div className="flex items-start justify-between gap-2">
                      <div className="text-xs font-semibold text-blue-700">
                        {product.category}
                      </div>
                      <span className="text-[11px] font-mono text-slate-500">
                        MOQ: {product.standardMoq}
                      </span>
                    </div>

                    <h3 className="mt-1.5 text-base font-bold text-slate-900 leading-snug">
                      {product.name}
                    </h3>

                    <p className="mt-1 text-xs text-slate-600 leading-relaxed line-clamp-2">
                      {product.description}
                    </p>

                    {/* Specific Technical Attributes (Unboxed text with subtle divider, zero-pill discipline) */}
                    <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 gap-2 text-xs">
                      {product.specHighlights.map((spec, i) => (
                        <div key={i} className="flex flex-col">
                          <span className="text-[11px] text-slate-500">{spec.label}</span>
                          <span className="font-semibold text-slate-800 font-mono text-[11px] truncate">
                            {spec.value}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Packaging Options */}
                    <div className="mt-4 pt-3 border-t border-slate-100">
                      <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-500 mb-1.5">
                        <PackageCheck className="w-3.5 h-3.5 text-blue-600" />
                        <span>Commercial Packaging:</span>
                      </div>
                      <div className="text-xs text-slate-700 leading-snug">
                        {product.packagingOptions.join(' · ')}
                      </div>
                    </div>
                  </div>

                  {/* Card Footer Actions */}
                  <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex flex-col gap-2">
                    <div className="grid grid-cols-2 gap-2">
                      {/* High-Converting Request Quote Button */}
                      <button
                        onClick={() => onQuickQuoteForProduct(product)}
                        className="w-full py-2 px-3 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Send className="w-3 h-3" />
                        <span>Request Quote</span>
                      </button>

                      {/* Add to Multi-Item RFQ Cart */}
                      <button
                        onClick={() => onAddToCart(product)}
                        className={`w-full py-2 px-3 text-xs font-semibold rounded-lg border transition-colors flex items-center justify-center gap-1.5 ${
                          inCart
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100 hover:text-slate-900'
                        }`}
                      >
                        {inCart ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-600" />
                            <span>In RFQ Cart</span>
                          </>
                        ) : (
                          <>
                            <Plus className="w-3 h-3" />
                            <span>Add to RFQ</span>
                          </>
                        )}
                      </button>
                    </div>

                    {/* Technical Specs & WhatsApp Row */}
                    <div className="flex items-center justify-between text-xs pt-1">
                      <button
                        onClick={() => onSelectProductForSpecs(product)}
                        className="text-slate-600 hover:text-blue-700 font-medium flex items-center gap-1 py-1"
                      >
                        <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                        <span>View Specs & COA</span>
                      </button>

                      <a
                        href={waUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-700 hover:text-emerald-800 font-medium flex items-center gap-1 py-1"
                      >
                        <span>WhatsApp RFQ</span>
                      </a>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};
