import React, { useState } from 'react';
import { Phone, Mail, MapPin, ShieldCheck, ChevronDown, ShoppingBag, Menu, X, ArrowUpRight, Search } from 'lucide-react';
import { COMPANY_PROFILE, DIVISIONS } from '../data/portalData';
import { DivisionId } from '../types';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onSelectDivision: (divisionId: DivisionId | 'all') => void;
  onSearchChange: (query: string) => void;
  searchQuery: string;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onSelectDivision,
  onSearchChange,
  searchQuery,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [divisionsDropdownOpen, setDivisionsDropdownOpen] = useState(false);

  const handleDivisionClick = (divId: DivisionId | 'all') => {
    onSelectDivision(divId);
    setDivisionsDropdownOpen(false);
    setMobileMenuOpen(false);
    const catalogElem = document.getElementById('catalog-section');
    if (catalogElem) {
      catalogElem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-900 border-b border-slate-800 text-white shadow-md">
      {/* Top Statutory & Dispatch Announcement Strip */}
      <div className="bg-slate-950 px-4 py-2 text-xs border-b border-slate-800 text-slate-300">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 font-mono text-[11px] tracking-tight">
            <span className="flex items-center gap-1.5 text-blue-400 font-semibold">
              <ShieldCheck className="w-3.5 h-3.5" />
              GSTIN: {COMPANY_PROFILE.gstin}
            </span>
            <span className="text-slate-600 hidden sm:inline" aria-hidden="true">·</span>
            <span className="flex items-center gap-1 text-slate-300 hidden md:inline-flex">
              <MapPin className="w-3 h-3 text-slate-400" />
              Bachupally, Hyderabad - 500090
            </span>
            <span className="text-slate-600 hidden lg:inline" aria-hidden="true">·</span>
            <span className="text-slate-400 hidden lg:inline">Prop. {COMPANY_PROFILE.proprietor}</span>
          </div>

          <div className="flex items-center gap-4 text-[11px]">
            <a
              href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
              className="flex items-center gap-1 text-slate-200 hover:text-white transition-colors"
            >
              <Phone className="w-3 h-3 text-emerald-400" />
              <span>Call: {COMPANY_PROFILE.primaryPhone}</span>
            </a>
            <span className="text-slate-700 hidden sm:inline" aria-hidden="true">/</span>
            <a
              href={`mailto:${COMPANY_PROFILE.salesEmail}`}
              className="hidden sm:flex items-center gap-1 text-slate-300 hover:text-white transition-colors"
            >
              <Mail className="w-3 h-3 text-blue-400" />
              <span>{COMPANY_PROFILE.salesEmail}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main Top Bar (Conforms strictly to 3-Zone Top Bar Contract) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark in display face */}
        <a
          href="#"
          className="text-xl sm:text-2xl font-extrabold tracking-tight text-white whitespace-nowrap shrink-0 hover:text-blue-400 transition-colors"
        >
          VAGDEVI INDUSTRIES
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden lg:flex items-center gap-7 text-sm font-medium text-slate-300">
          <div className="relative">
            <button
              onClick={() => setDivisionsDropdownOpen(!divisionsDropdownOpen)}
              className="flex items-center gap-1 hover:text-white transition-colors whitespace-nowrap shrink-0 py-1"
            >
              <span>Divisions</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${divisionsDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Mega Dropdown for 4 Vertical Divisions */}
            {divisionsDropdownOpen && (
              <div
                className="absolute left-0 mt-2 w-96 rounded-xl bg-slate-900 border border-slate-700 shadow-2xl p-3 grid gap-2 z-50 text-left"
                onMouseLeave={() => setDivisionsDropdownOpen(false)}
              >
                <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 tracking-wider uppercase border-b border-slate-800">
                  Four Vertical Divisions
                </div>
                {DIVISIONS.map((div) => (
                  <button
                    key={div.id}
                    onClick={() => handleDivisionClick(div.id)}
                    className="flex flex-col p-2.5 rounded-lg hover:bg-slate-800/80 transition-colors text-left group"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-white group-hover:text-blue-400 transition-colors">
                        {div.name}
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-blue-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <span className="text-xs text-slate-400 line-clamp-1 mt-0.5">{div.subtitle}</span>
                  </button>
                ))}
                <div className="pt-1 border-t border-slate-800">
                  <button
                    onClick={() => handleDivisionClick('all')}
                    className="w-full text-center py-1.5 text-xs font-semibold text-blue-400 hover:text-blue-300 transition-colors"
                  >
                    View All Products & Specifications →
                  </button>
                </div>
              </div>
            )}
          </div>

          <a href="#catalog-section" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Product Catalog
          </a>
          <a href="#why-choose-us" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Why Choose Us
          </a>
          <a href="#compliance" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Quality & Compliance
          </a>
          <a href="#contact-section" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Contact Sales Desk
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Quick Search Bar trigger for catalog */}
          <div className="hidden md:flex items-center relative">
            <Search className="w-3.5 h-3.5 absolute left-3 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search products, CAS, mesh..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-48 lg:w-56 bg-slate-800 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:w-64 transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2 text-slate-400 hover:text-white text-xs"
              >
                ×
              </button>
            )}
          </div>

          {/* Primary Action Button */}
          <button
            onClick={onOpenCart}
            className="relative flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm"
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Request Multi-Product Quote</span>
            {cartCount > 0 && (
              <span className="flex items-center justify-center bg-white text-blue-900 font-bold text-[11px] rounded-full w-5 h-5 ml-0.5">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            aria-label="Toggle Navigation"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-slate-950 border-t border-slate-800 px-4 py-4 space-y-3">
          <div className="relative mb-3">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Search products, CAS numbers, mesh..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-2 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2">
            Enterprise Divisions
          </div>
          <div className="grid grid-cols-1 gap-1">
            {DIVISIONS.map((div) => (
              <button
                key={div.id}
                onClick={() => handleDivisionClick(div.id)}
                className="text-left px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-slate-900 hover:text-blue-400 transition-colors"
              >
                {div.name}
              </button>
            ))}
            <button
              onClick={() => handleDivisionClick('all')}
              className="text-left px-3 py-2 rounded-lg text-sm text-blue-400 hover:bg-slate-900 font-medium"
            >
              View Full Product Catalog
            </button>
          </div>

          <div className="pt-2 border-t border-slate-800 space-y-1">
            <a
              href="#why-choose-us"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 hover:text-white"
            >
              Why Choose Us
            </a>
            <a
              href="#compliance"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 hover:text-white"
            >
              Quality & Batch Testing
            </a>
            <a
              href="#contact-section"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-900 hover:text-white"
            >
              Contact Sales Desk
            </a>
          </div>

          <div className="pt-3 border-t border-slate-800 flex flex-col gap-2">
            <a
              href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
              className="flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-slate-800 text-xs font-medium text-slate-200 hover:bg-slate-700"
            >
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              Call Hotline: {COMPANY_PROFILE.primaryPhone}
            </a>
            <a
              href={COMPANY_PROFILE.whatsAppLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 py-2 px-4 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-xs font-medium text-white"
            >
              Direct WhatsApp Inquiry
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
