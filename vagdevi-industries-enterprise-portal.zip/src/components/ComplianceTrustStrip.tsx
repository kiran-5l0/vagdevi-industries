import React from 'react';
import { ShieldCheck, Award, FileSpreadsheet, CheckCircle, Truck, Building } from 'lucide-react';
import { COMPANY_PROFILE } from '../data/portalData';

export const ComplianceTrustStrip: React.FC = () => {
  return (
    <section id="compliance" className="py-14 bg-slate-900 text-white border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-8">
          {/* Statutory Credential Block */}
          <div className="max-w-xl">
            <div className="flex items-center gap-2 text-xs font-mono text-blue-400 mb-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>STATUTORY COMPLIANCE & GOVERNANCE</span>
            </div>
            <h2 className="text-2xl font-bold tracking-tight text-white leading-snug">
              Certified Enterprise Standards & Transparent Governance
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
              Every shipment from Vagdevi Industries is dispatched under our verified GST registration,
              accompanied by mandatory batch analytical reports (COA), E-Way bills, and safety documentation.
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-3 text-xs font-mono">
              <div className="bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                <span className="text-slate-400">GSTIN:</span>{' '}
                <span className="font-bold text-blue-400">{COMPANY_PROFILE.gstin}</span>
              </div>
              <div className="bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
                <span className="text-slate-400">Proprietor:</span>{' '}
                <span className="font-bold text-slate-200">{COMPANY_PROFILE.proprietor}</span>
              </div>
            </div>
          </div>

          {/* Compliance Checklist Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full lg:w-auto">
            <div className="p-4 bg-slate-800/70 border border-slate-700/80 rounded-xl">
              <div className="flex items-center gap-2 text-emerald-400 mb-1">
                <CheckCircle className="w-4 h-4" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Chemical Lab Verification
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Lot-specific Certificate of Analysis (COA) specifying assay %, Fe content, and specific gravity provided with every consignment.
              </p>
            </div>

            <div className="p-4 bg-slate-800/70 border border-slate-700/80 rounded-xl">
              <div className="flex items-center gap-2 text-blue-400 mb-1">
                <Award className="w-4 h-4" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Food Grade & FSSAI Standards
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Dehydrated agro flakes, powders, and wholesale dry fruits handled under strict hygienic packaging with zero artificial colors or adulteration.
              </p>
            </div>

            <div className="p-4 bg-slate-800/70 border border-slate-700/80 rounded-xl">
              <div className="flex items-center gap-2 text-indigo-400 mb-1">
                <FileSpreadsheet className="w-4 h-4" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Packaging BF & ECT Testing
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Corrugated cartons tested for Bursting Factor (18–36 BF), Edge Crush Test (ECT), and moisture absorption cobb values before dispatch.
              </p>
            </div>

            <div className="p-4 bg-slate-800/70 border border-slate-700/80 rounded-xl">
              <div className="flex items-center gap-2 text-amber-400 mb-1">
                <Truck className="w-4 h-4" />
                <span className="text-xs font-bold text-white uppercase tracking-wider">
                  Hazmat & Road Transport Safe
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Acid tankers and carboys transported strictly via TREMCARD-equipped vehicles with hazardous material handling driver certification.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
