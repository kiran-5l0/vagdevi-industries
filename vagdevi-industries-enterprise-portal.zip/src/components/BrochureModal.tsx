import React from 'react';
import { X, Printer, Download, ShieldCheck, Phone, Mail, MapPin, Building2, Package } from 'lucide-react';
import { COMPANY_PROFILE, DIVISIONS, PRODUCTS } from '../data/portalData';

interface BrochureModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const BrochureModal: React.FC<BrochureModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="relative bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Package className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-base font-bold text-white">
                Vagdevi Industries — Unified Enterprise Product Catalog
              </h3>
              <div className="text-[11px] font-mono text-slate-400">
                Official Corporate Profile & Multi-Division Specifications
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Brochure Printable Content */}
        <div className="p-6 sm:p-8 max-h-[80vh] overflow-y-auto space-y-8 print:p-0 print:max-h-none print:overflow-visible">
          {/* Cover & Corporate Identity */}
          <div className="border-b border-slate-200 pb-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                  VAGDEVI INDUSTRIES
                </h1>
                <p className="text-xs font-mono text-slate-500 mt-0.5">
                  Legal Entity: {COMPANY_PROFILE.proprietor} · GSTIN: {COMPANY_PROFILE.gstin}
                </p>
                <p className="text-xs text-slate-600 mt-1 max-w-xl">
                  {COMPANY_PROFILE.registeredAddress}
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs font-mono text-slate-700 shrink-0">
                <div>Hotline: {COMPANY_PROFILE.primaryPhone}</div>
                <div>Secondary: {COMPANY_PROFILE.secondaryPhone}</div>
                <div>Email: {COMPANY_PROFILE.salesEmail}</div>
              </div>
            </div>
          </div>

          {/* 4 Divisions Summary */}
          {DIVISIONS.map((div) => {
            const divProducts = PRODUCTS.filter((p) => p.divisionId === div.id);
            return (
              <div key={div.id} className="space-y-3">
                <div className="border-b-2 border-slate-900 pb-1.5 flex items-center justify-between">
                  <h3 className="text-base font-bold text-slate-900 uppercase tracking-wide">
                    {div.name}
                  </h3>
                  <span className="text-xs font-mono text-slate-500">
                    {divProducts.length} Standard Products
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {div.scope}
                </p>

                {/* Table of Products in this Division */}
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-200">
                      <tr>
                        <th className="px-3 py-2">Product Name</th>
                        <th className="px-3 py-2">Key Specification / CAS / BF</th>
                        <th className="px-3 py-2">Standard Packaging</th>
                        <th className="px-3 py-2 text-right">Standard MOQ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-800">
                      {divProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="px-3 py-2 font-medium text-slate-900">
                            {p.name}
                          </td>
                          <td className="px-3 py-2 text-slate-600 font-mono text-[11px]">
                            {p.casNumber ? `CAS: ${p.casNumber} · ` : ''}
                            {p.purity || p.meshSize || p.countPerLb || p.burstingFactor || 'Standard Grade'}
                          </td>
                          <td className="px-3 py-2 text-slate-600">
                            {p.packagingOptions[0]}
                          </td>
                          <td className="px-3 py-2 text-right font-mono font-semibold text-slate-900">
                            {p.standardMoq}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            );
          })}

          {/* Statutory Sign-off */}
          <div className="pt-6 border-t border-slate-200 flex flex-wrap items-center justify-between text-xs text-slate-500 gap-4">
            <div>
              <span>Official Vagdevi Industries Catalog · Bachupally, Hyderabad · Dispatch Pan-India</span>
            </div>
            <div className="font-mono">
              For Bulk Contract Bookings: salesh.vagdevi6@gmail.com
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Click 'Print / Save PDF' to generate an offline copy or print
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
