import React from 'react';
import { X, FileText, CheckCircle2, Package, ShieldCheck, Printer, Send, MessageCircle } from 'lucide-react';
import { Product } from '../types';
import { COMPANY_PROFILE } from '../data/portalData';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToRFQ: (product: Product) => void;
  isInCart: boolean;
  onQuickQuote: (product: Product) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToRFQ,
  isInCart,
  onQuickQuote,
}) => {
  if (!product) return null;

  const handlePrintCOA = () => {
    window.print();
  };

  const waText = encodeURIComponent(
    `Hello Vagdevi Industries, I am reviewing the technical specifications for *${product.name}* (CAS/Standard: ${product.casNumber || product.grade || 'Standard'}). Please share current lot COA, availability, and bulk pricing for delivery to our unit.`
  );
  const waUrl = `https://wa.me/${COMPANY_PROFILE.primaryPhoneRaw}?text=${waText}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-fade-in">
      <div className="relative bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div>
            <div className="text-[11px] font-mono text-blue-400 tracking-wider uppercase">
              {product.divisionName} · Technical Data Sheet
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-white mt-0.5">
              {product.name}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 max-w-none max-h-[75vh] overflow-y-auto space-y-6">
          {/* Statutory & Lab Certification Header */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span className="font-semibold text-slate-800">
                Statutory Batch Standard: ISO Aligned · COA / MSDS Verified
              </span>
            </div>
            <div className="font-mono text-slate-500">
              GSTIN: {COMPANY_PROFILE.gstin}
            </div>
          </div>

          {/* Description */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1.5">
              Product Overview & Scope
            </h4>
            <p className="text-sm text-slate-700 leading-relaxed">
              {product.description}
            </p>
          </div>

          {/* Primary Technical Attributes Grid */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2.5">
              Technical Parameters & Specifications
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {product.formula && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Chemical Formula</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.formula}</div>
                </div>
              )}
              {product.casNumber && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">CAS Registry No.</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.casNumber}</div>
                </div>
              )}
              {product.purity && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Assay / Purity</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.purity}</div>
                </div>
              )}
              {product.grade && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Commercial Grade</span>
                  <div className="text-sm font-bold text-slate-900">{product.grade}</div>
                </div>
              )}
              {product.meshSize && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Mesh / Granule Size</span>
                  <div className="text-sm font-bold text-slate-900">{product.meshSize}</div>
                </div>
              )}
              {product.moisture && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Moisture Content</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.moisture}</div>
                </div>
              )}
              {product.ashContent && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Total Ash</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.ashContent}</div>
                </div>
              )}
              {product.microbialStandard && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Microbial Standard</span>
                  <div className="text-xs font-semibold text-slate-900">{product.microbialStandard}</div>
                </div>
              )}
              {product.shelfLife && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Shelf Life</span>
                  <div className="text-sm font-bold text-slate-900">{product.shelfLife}</div>
                </div>
              )}
              {product.origin && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Origin / Sourcing</span>
                  <div className="text-sm font-bold text-slate-900">{product.origin}</div>
                </div>
              )}
              {product.countPerLb && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Count / Caliber</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.countPerLb}</div>
                </div>
              )}
              {product.burstingFactor && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Bursting Factor (BF)</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.burstingFactor}</div>
                </div>
              )}
              {product.fluting && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Fluting Profile</span>
                  <div className="text-sm font-bold text-slate-900">{product.fluting}</div>
                </div>
              )}
              {product.gsm && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Paper GSM</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.gsm}</div>
                </div>
              )}
              {product.compressionStrength && (
                <div className="bg-slate-50 p-3 rounded-lg border border-slate-200">
                  <span className="text-[11px] text-slate-500">Compression Strength</span>
                  <div className="text-sm font-bold font-mono text-slate-900">{product.compressionStrength}</div>
                </div>
              )}
            </div>
          </div>

          {/* Sample Certificate of Analysis (COA) / Batch Testing Table if present */}
          {product.sampleSpecs && product.sampleSpecs.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  <span>Representative Batch Certificate of Analysis (COA)</span>
                </h4>
                <span className="text-[11px] font-mono text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Batch Quality Passed
                </span>
              </div>

              <div className="border border-slate-200 rounded-lg overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 text-slate-700 border-b border-slate-200 font-semibold">
                    <tr>
                      <th className="px-3.5 py-2">Test Parameter</th>
                      <th className="px-3.5 py-2">Standard Specification</th>
                      <th className="px-3.5 py-2">Observed Result</th>
                      <th className="px-3.5 py-2 text-right">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono text-slate-800">
                    {product.sampleSpecs.map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="px-3.5 py-2 font-sans font-medium text-slate-900">
                          {row.testParameter}
                        </td>
                        <td className="px-3.5 py-2 text-slate-600">{row.specification}</td>
                        <td className="px-3.5 py-2 font-bold text-slate-900">{row.result}</td>
                        <td className="px-3.5 py-2 text-right text-emerald-600 font-sans font-semibold">
                          Conforms
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Packaging & Logistics Details */}
          <div className="p-4 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-slate-700">
            <div className="font-bold text-blue-900 flex items-center gap-1.5 mb-1">
              <Package className="w-4 h-4 text-blue-700" />
              <span>Standard Packaging & Logistics Delivery</span>
            </div>
            <p className="mt-1 leading-relaxed">
              Available in: {product.packagingOptions.join(', ')}. Minimum order quantity is{' '}
              <strong className="text-slate-900">{product.standardMoq}</strong>. Pan-India dispatch from Bachupally, Hyderabad with verified road freight or dedicated tanker logistics.
            </p>
          </div>
        </div>

        {/* Modal Footer Controls */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintCOA}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 hover:text-slate-900 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5"
            >
              <Printer className="w-3.5 h-3.5 text-slate-500" />
              <span>Print / Save TDS</span>
            </button>
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3.5 py-2 text-xs font-semibold text-emerald-800 bg-emerald-100/80 hover:bg-emerald-200 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5 text-emerald-600" />
              <span>WhatsApp Inquiry</span>
            </a>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onAddToRFQ(product)}
              className={`px-4 py-2 text-xs font-semibold rounded-lg border transition-colors ${
                isInCart
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
                  : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {isInCart ? 'In RFQ List ✓' : '+ Add to RFQ List'}
            </button>

            <button
              onClick={() => {
                onQuickQuote(product);
                onClose();
              }}
              className="px-5 py-2 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Request Formal Quote</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
