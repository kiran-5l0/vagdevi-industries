import React from 'react';
import { MessageCircle, Phone, ShoppingBag } from 'lucide-react';
import { COMPANY_PROFILE } from '../data/portalData';

interface FloatingActionsProps {
  cartCount: number;
  onOpenCart: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({
  cartCount,
  onOpenCart,
}) => {
  return (
    <aside aria-label="Quick contact and RFQ actions" className="fixed bottom-5 right-5 z-40 flex flex-col items-end gap-2.5">
      {/* RFQ Cart Launcher Floating Badge (if items exist or quick quote) */}
      <button
        onClick={onOpenCart}
        className="group relative flex items-center gap-2 px-3.5 py-2.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200"
        aria-label="View RFQ Quote Cart"
      >
        <ShoppingBag className="w-4 h-4" />
        <span className="text-xs font-bold hidden sm:inline">RFQ Cart</span>
        {cartCount > 0 && (
          <span className="flex items-center justify-center bg-white text-blue-900 font-bold text-[11px] rounded-full w-5 h-5">
            {cartCount}
          </span>
        )}
      </button>

      {/* Call Us Now Floating Action */}
      <a
        href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
        className="group flex items-center gap-2 px-3.5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-200 border border-slate-700"
        aria-label="Call Vagdevi Industries Sales Desk"
      >
        <Phone className="w-4 h-4 text-emerald-400" />
        <span className="text-xs font-semibold hidden sm:inline">Call Us Now</span>
      </a>

      {/* WhatsApp Inquiry Floating Action */}
      <a
        href={COMPANY_PROFILE.whatsAppLink}
        target="_blank"
        rel="noopener noreferrer"
        className="group flex items-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full shadow-xl hover:shadow-2xl hover:scale-105 transition-all duration-200"
        aria-label="WhatsApp Inquiry with Vagdevi Industries"
      >
        <MessageCircle className="w-5 h-5 fill-white text-emerald-600" />
        <span className="text-xs font-bold">WhatsApp Inquiry</span>
      </a>
    </aside>
  );
};
