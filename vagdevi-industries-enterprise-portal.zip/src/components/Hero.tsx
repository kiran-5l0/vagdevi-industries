import React from 'react';
import { ArrowRight, Phone, FileSpreadsheet, ShieldCheck, Truck, Factory, Sparkles } from 'lucide-react';
import { COMPANY_PROFILE, DIVISIONS } from '../data/portalData';
import { DivisionId } from '../types';

interface HeroProps {
  onSelectDivision: (id: DivisionId) => void;
  onOpenRFQ: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onSelectDivision, onOpenRFQ }) => {
  return (
    <section className="relative bg-slate-900 text-white overflow-hidden border-b border-slate-800">
      {/* Background Hero Image with measured contrast scrim for accessibility */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_vagdevi_industrial_1792511416986.jpg"
          alt="Vagdevi Industries Multi-Sector Logistics and Manufacturing Hub"
          className="w-full h-full object-cover opacity-25 filter brightness-75 scale-105 transition-transform duration-1000"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-900/85 to-slate-950" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-16 lg:pt-16 lg:pb-20">
        {/* Editorial Subhead / Kicker (Unboxed text with typographic separator, zero-pill discipline) */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-blue-400 mb-4 tracking-wide uppercase">
          <span>Enterprise B2B Conglomerate</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Bachupally, Hyderabad</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span>Pan-India Supply Chain</span>
        </div>

        {/* Primary Hero Headline (text-wrap: balance to prevent orphan lines) */}
        <div className="max-w-4xl">
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight [text-wrap:balance]">
            Single-Source Partner for Industrial Chemicals, Agro Dehydrates, Premium Dry Fruits & Corrugated Packaging
          </h1>

          <p className="mt-5 text-base sm:text-lg text-slate-300 leading-relaxed max-w-3xl">
            Vagdevi Industries consolidates four specialized manufacturing and wholesale verticals under one
            statutory roof. Streamline your supply chain with direct manufacturer pricing, verified batch COA/MSDS
            testing, and prompt dispatch from Bachupally, Hyderabad.
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button
              onClick={onOpenRFQ}
              className="px-6 py-3.5 text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 rounded-lg shadow-lg hover:shadow-blue-500/20 transition-all flex items-center gap-2"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Submit Multi-Product Quote</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <a
              href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
              className="px-5 py-3.5 text-sm font-semibold text-slate-200 hover:text-white bg-slate-800/90 hover:bg-slate-700/90 border border-slate-700 rounded-lg transition-colors flex items-center gap-2"
            >
              <Phone className="w-4 h-4 text-emerald-400" />
              <span>Direct Sales Desk: {COMPANY_PROFILE.primaryPhone}</span>
            </a>

            <a
              href="#catalog-section"
              className="px-4 py-3.5 text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors"
            >
              Explore Full Catalog ↓
            </a>
          </div>
        </div>

        {/* 4 Division Quick-Access Cards (Bento Portal Cards) */}
        <div className="mt-14">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Four Core Specialized Operating Divisions
            </h2>
            <span className="text-xs text-slate-500 hidden sm:inline">
              Click any division to browse technical specifications
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {DIVISIONS.map((div, idx) => (
              <div
                key={div.id}
                onClick={() => onSelectDivision(div.id)}
                className="group relative bg-slate-800/80 hover:bg-slate-800 border border-slate-700/80 hover:border-blue-500/50 rounded-xl overflow-hidden cursor-pointer transition-all duration-300 flex flex-col justify-between shadow-md hover:shadow-xl hover:-translate-y-0.5"
              >
                {/* Visual Thumbnail */}
                <div className="relative h-40 w-full overflow-hidden bg-slate-950">
                  <img
                    src={div.image}
                    alt={div.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
                  <div className="absolute top-2.5 left-2.5 text-[11px] font-mono text-slate-300 bg-slate-950/70 backdrop-blur-sm px-2 py-0.5 rounded border border-slate-800">
                    Division 0{idx + 1}
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors leading-snug">
                      {div.name}
                    </h3>
                    <p className="mt-1.5 text-xs text-slate-300 line-clamp-2 leading-relaxed">
                      {div.subtitle}
                    </p>
                  </div>

                  {/* Highlights and Quick CTA */}
                  <div className="mt-4 pt-3 border-t border-slate-700/60 flex items-center justify-between text-xs">
                    <span className="font-mono text-slate-400 text-[11px]">
                      {div.stat.value}
                    </span>
                    <span className="inline-flex items-center gap-1 font-semibold text-blue-400 group-hover:translate-x-0.5 transition-transform">
                      Browse Specs
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Full-width Row Proof & Dispatch Strip */}
        <div className="mt-10 pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6 text-slate-300">
          <div className="flex items-center gap-3">
            <Factory className="w-5 h-5 text-blue-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-white">Direct Manufacturer</div>
              <div className="text-slate-400">Zero Intermediary Margins</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-white">COA & MSDS Testing</div>
              <div className="text-slate-400">Every Batch Chemically Tested</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Truck className="w-5 h-5 text-indigo-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-white">Pan-India Dispatch</div>
              <div className="text-slate-400">Tankers, FCL & LTL Freight</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            <div className="text-xs">
              <div className="font-bold text-white">Single-Window Billing</div>
              <div className="text-slate-400">GSTIN: 36CBLPG2247K1ZH</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
