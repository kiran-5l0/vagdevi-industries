import React from 'react';
import { MapPin, Phone, Mail, ShieldCheck, ArrowUpRight, MessageCircle } from 'lucide-react';
import { COMPANY_PROFILE, DIVISIONS } from '../data/portalData';
import { DivisionId } from '../types';

interface FooterProps {
  onSelectDivision: (id: DivisionId) => void;
  onOpenBrochure: () => void;
  onOpenRFQ: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectDivision,
  onOpenBrochure,
  onOpenRFQ,
}) => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      {/* Main Footer Directory */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-14 pb-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Col 1 & 2: Corporate Brand & Profile */}
          <div className="lg:col-span-2 space-y-4">
            <div>
              <h2 className="text-xl font-bold tracking-tight text-white">
                VAGDEVI INDUSTRIES
              </h2>
              <div className="text-xs font-mono text-slate-400 mt-1">
                Proprietorship: {COMPANY_PROFILE.proprietor}
              </div>
              <div className="text-xs font-mono text-blue-400 mt-0.5">
                GSTIN: {COMPANY_PROFILE.gstin}
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              Single-source enterprise B2B conglomerate partnering with industrial manufacturers, food processors, confectioners, and logistics operators across India.
            </p>

            {/* Address */}
            <div className="pt-2 text-xs text-slate-400 space-y-1">
              <div className="flex items-start gap-2">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                <address className="not-italic leading-relaxed">
                  {COMPANY_PROFILE.registeredAddress}
                </address>
              </div>
            </div>

            {/* Quick Contact Links */}
            <div className="pt-2 flex flex-wrap items-center gap-3 text-xs">
              <a
                href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
                className="text-slate-300 hover:text-white flex items-center gap-1 font-mono"
              >
                <Phone className="w-3 h-3 text-emerald-400" />
                <span>{COMPANY_PROFILE.primaryPhone}</span>
              </a>
              <span className="text-slate-700">·</span>
              <a
                href={`mailto:${COMPANY_PROFILE.salesEmail}`}
                className="text-slate-300 hover:text-white flex items-center gap-1 font-mono"
              >
                <Mail className="w-3 h-3 text-blue-400" />
                <span>{COMPANY_PROFILE.salesEmail}</span>
              </a>
            </div>
          </div>

          {/* Col 3: Four Operating Divisions */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Four Divisions
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              {DIVISIONS.map((div) => (
                <li key={div.id}>
                  <button
                    onClick={() => {
                      onSelectDivision(div.id);
                      const catalogElem = document.getElementById('catalog-section');
                      if (catalogElem) catalogElem.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="hover:text-blue-400 transition-colors text-left flex items-center gap-1 group"
                  >
                    <span>{div.name}</span>
                    <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4: Key Product Groups */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Popular Catalog Lines
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>Hydrochloric Acid (30–33%)</li>
              <li>Caustic Soda Flakes 98.5%</li>
              <li>Dehydrated Onion Flakes & Powder</li>
              <li>Dehydrated Garlic Granules</li>
              <li>Jumbo Cashews (W180, W240, W320)</li>
              <li>California Nonpareil Almonds</li>
              <li>3-Ply & 5-Ply Corrugated Cartons</li>
              <li>Chemical Carboy Outer Packaging</li>
            </ul>
          </div>

          {/* Col 5: Compliance & Downloads */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Procurement & Tools
            </h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>
                <button
                  onClick={onOpenRFQ}
                  className="hover:text-white transition-colors text-blue-400 font-semibold"
                >
                  → Request Multi-Product RFQ
                </button>
              </li>
              <li>
                <button
                  onClick={onOpenBrochure}
                  className="hover:text-white transition-colors"
                >
                  Download Corporate Brochure
                </button>
              </li>
              <li>
                <a
                  href={COMPANY_PROFILE.whatsAppLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-1 text-emerald-400"
                >
                  <MessageCircle className="w-3 h-3" />
                  <span>WhatsApp Commercial Desk</span>
                </a>
              </li>
              <li>
                <a
                  href="#compliance"
                  className="hover:text-white transition-colors"
                >
                  Statutory GSTIN & Lab Standards
                </a>
              </li>
              <li>
                <a
                  href="#contact-section"
                  className="hover:text-white transition-colors"
                >
                  Bachupally Logistics Hub Map
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Quiet Sub-Footer */}
        <div className="mt-12 pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-3">
          <div>
            © {new Date().getFullYear()} Vagdevi Industries. All rights reserved. GSTIN: {COMPANY_PROFILE.gstin}.
          </div>
          <div className="flex items-center gap-4 text-[11px] font-mono">
            <span>Bachupally, Hyderabad - 500090</span>
            <span aria-hidden="true">·</span>
            <span>Telangana, India</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
