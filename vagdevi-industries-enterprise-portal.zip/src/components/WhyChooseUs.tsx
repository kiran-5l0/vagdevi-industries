import React from 'react';
import { DollarSign, ShieldCheck, Cog, Truck, ArrowRight } from 'lucide-react';
import { TRUST_PILLARS, FAQ_LIST } from '../data/portalData';

interface WhyChooseUsProps {
  onOpenRFQ: () => void;
}

export const WhyChooseUs: React.FC<WhyChooseUsProps> = ({ onOpenRFQ }) => {
  return (
    <section id="why-choose-us" className="py-16 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="text-xs font-semibold text-blue-700 tracking-wider uppercase mb-2">
            Enterprise Value Proposition
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight [text-wrap:balance]">
            Why Industrial Buyers Partner with Vagdevi Industries
          </h2>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            Consolidating chemical synthesis, agro-dehydration, wholesale nut grading, and heavy packaging under one management structure gives our enterprise clients unbeatable cost, logistics, and accountability advantages.
          </p>
        </div>

        {/* 4 Core Pillars Grid */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {TRUST_PILLARS.map((pillar, idx) => {
            const icons = [
              <DollarSign className="w-5 h-5 text-blue-600" />,
              <ShieldCheck className="w-5 h-5 text-emerald-600" />,
              <Cog className="w-5 h-5 text-indigo-600" />,
              <Truck className="w-5 h-5 text-amber-600" />,
            ];

            return (
              <div
                key={idx}
                className="bg-slate-50 border border-slate-200/90 rounded-xl p-5 hover:border-blue-400 transition-colors flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-2xs">
                      {icons[idx % icons.length]}
                    </div>
                    <span className="font-mono text-xs font-bold text-blue-800 bg-blue-50 px-2 py-0.5 rounded">
                      {pillar.metric}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 leading-snug">
                    {pillar.title}
                  </h3>

                  <p className="mt-2 text-xs text-slate-600 leading-relaxed">
                    {pillar.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-200/80 text-[11px] font-mono text-slate-500">
                  Standard Verified 0{idx + 1}
                </div>
              </div>
            );
          })}
        </div>

        {/* FAQ Section */}
        <div className="mt-16 pt-12 border-t border-slate-200">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-xl font-bold text-slate-900 text-center mb-8">
              Frequently Asked B2B Procurement Questions
            </h3>

            <div className="space-y-4">
              {FAQ_LIST.map((faq, i) => (
                <div
                  key={i}
                  className="bg-slate-50 border border-slate-200 rounded-xl p-4 sm:p-5"
                >
                  <h4 className="text-sm font-bold text-slate-900 mb-2">
                    {faq.question}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              ))}
            </div>

            <div className="mt-8 text-center">
              <button
                onClick={onOpenRFQ}
                className="px-6 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors inline-flex items-center gap-2"
              >
                <span>Request Custom Consignment Quote</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
