import React, { useState } from 'react';
import {
  X,
  Trash2,
  Send,
  MessageCircle,
  Building,
  MapPin,
  Mail,
  Phone,
  CheckCircle2,
  FileSpreadsheet,
  AlertCircle,
  Copy,
  Plus,
} from 'lucide-react';
import { CartItem, DivisionId, Product } from '../types';
import { COMPANY_PROFILE, PRODUCTS, DIVISIONS } from '../data/portalData';

interface MultiProductRFQModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onRemoveItem: (productId: string) => void;
  onUpdateQuantity: (productId: string, quantity: string) => void;
  onClearCart: () => void;
  initialProduct?: Product | null;
}

export const MultiProductRFQModal: React.FC<MultiProductRFQModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onRemoveItem,
  onUpdateQuantity,
  onClearCart,
  initialProduct,
}) => {
  // Form fields
  const [fullName, setFullName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [deliveryLocation, setDeliveryLocation] = useState('');
  const [pinCode, setPinCode] = useState('');
  const [customNotes, setCustomNotes] = useState('');
  const [standaloneProduct, setStandaloneProduct] = useState(initialProduct?.name || '');
  const [standaloneQuantity, setStandaloneQuantity] = useState(initialProduct?.standardMoq || '1 MT');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<null | {
    rfqId: string;
    waUrl: string;
    receivedAt: string;
  }>(null);
  const [formError, setFormError] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  if (!isOpen) return null;

  // Build items array either from cart or standalone
  const activeItems = cartItems.length > 0
    ? cartItems.map((ci) => ({
        productId: ci.product.id,
        productName: ci.product.name,
        divisionId: ci.product.divisionId,
        quantity: ci.quantity,
        targetSpecs: ci.targetSpecs || ci.product.standardMoq,
      }))
    : initialProduct
    ? [
        {
          productId: initialProduct.id,
          productName: initialProduct.name,
          divisionId: initialProduct.divisionId,
          quantity: standaloneQuantity,
          targetSpecs: initialProduct.standardMoq,
        },
      ]
    : [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // Form validation
    if (!fullName.trim()) {
      setFormError('Please enter your full name.');
      return;
    }
    if (!phoneNumber.trim() || phoneNumber.trim().length < 8) {
      setFormError('Please provide a valid contact phone number.');
      return;
    }
    if (!emailAddress.trim() || !emailAddress.includes('@')) {
      setFormError('Please provide a valid business email address.');
      return;
    }

    if (activeItems.length === 0 && !standaloneProduct.trim()) {
      setFormError('Please add at least one product or specify your target requirement.');
      return;
    }

    setIsSubmitting(true);

    // Build payload
    const selectedDivisions = Array.from(
      new Set(activeItems.map((i) => i.divisionId))
    );

    const payload = {
      name: fullName.trim(),
      company: companyName.trim() || 'Direct Inquiry',
      phone: phoneNumber.trim(),
      email: emailAddress.trim(),
      location: deliveryLocation.trim() || 'Pan-India',
      pincode: pinCode.trim(),
      divisions: selectedDivisions.length > 0 ? selectedDivisions : ['conglomerate'],
      items: activeItems.length > 0 ? activeItems : [
        {
          productId: 'custom-inquiry',
          productName: standaloneProduct.trim(),
          divisionId: 'conglomerate',
          quantity: standaloneQuantity.trim(),
        },
      ],
      message: customNotes.trim(),
    };

    try {
      const response = await fetch('/api/rfq', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        // Compose WhatsApp pre-filled message
        const itemsSummary = payload.items
          .map((item: any, idx: number) => `${idx + 1}. *${item.productName}* — Qty: ${item.quantity}`)
          .join('\n');

        const waText = encodeURIComponent(
          `*NEW RFQ SUBMISSION — VAGDEVI INDUSTRIES*\n` +
          `Ref ID: *${data.rfqId}*\n\n` +
          `*Buyer Details:*\n` +
          `Name: ${payload.name}\n` +
          `Company: ${payload.company}\n` +
          `Phone: ${payload.phone}\n` +
          `Email: ${payload.email}\n` +
          `Delivery Location: ${payload.location} (PIN: ${payload.pincode || 'N/A'})\n\n` +
          `*Requested Products:*\n${itemsSummary}\n\n` +
          `*Notes / Custom Specs:*\n${payload.message || 'Standard batch specification required.'}\n\n` +
          `_Notification forwarded to salesh.vagdevi6@gmail.com_`
        );

        const waUrl = `https://wa.me/${COMPANY_PROFILE.primaryPhoneRaw}?text=${waText}`;

        setSubmissionSuccess({
          rfqId: data.rfqId,
          waUrl,
          receivedAt: data.receivedAt,
        });

        // Clear cart after successful submission
        onClearCart();
      } else {
        setFormError(data.error || 'Failed to submit quote request. Please retry or contact via WhatsApp.');
      }
    } catch (err) {
      console.error('RFQ submission error:', err);
      // Fallback: still generate WhatsApp URL and reference ID even if server is offline
      const fallbackId = `RFQ-VGD-${Date.now().toString(36).toUpperCase()}`;
      const waFallbackText = encodeURIComponent(
        `*OFFICIAL RFQ INQUIRY — VAGDEVI INDUSTRIES*\nRef: ${fallbackId}\nFrom: ${payload.name} (${payload.company})\nPhone: ${payload.phone}\nProduct(s): ${payload.items.map((i: any) => i.productName + ' (' + i.quantity + ')').join(', ')}\nLocation: ${payload.location}`
      );
      setSubmissionSuccess({
        rfqId: fallbackId,
        waUrl: `https://wa.me/${COMPANY_PROFILE.primaryPhoneRaw}?text=${waFallbackText}`,
        receivedAt: new Date().toISOString(),
      });
      onClearCart();
    } finally {
      setIsSubmitting(false);
    }
  };

  const copyRefId = () => {
    if (submissionSuccess) {
      navigator.clipboard.writeText(submissionSuccess.rfqId);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div className="relative bg-white rounded-2xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <FileSpreadsheet className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-base sm:text-lg font-bold text-white">
                Request Multi-Product Commercial Quotation
              </h3>
              <div className="text-[11px] font-mono text-slate-400">
                Direct Desk: {COMPANY_PROFILE.salesEmail} · +91 8639638288
              </div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success View */}
        {submissionSuccess ? (
          <div className="p-6 sm:p-8 space-y-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="text-xl font-bold text-slate-900">
                Request For Quote Registered!
              </h4>
              <p className="mt-1 text-xs sm:text-sm text-slate-600 max-w-md mx-auto">
                Your RFQ has been logged and forwarded to our official enterprise sales inbox{' '}
                <strong className="text-slate-900">{COMPANY_PROFILE.salesEmail}</strong>.
              </p>
            </div>

            {/* Reference Card */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-center">
              <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider">
                Official Reference ID
              </span>
              <div className="mt-1 flex items-center justify-center gap-2">
                <span className="text-lg font-mono font-bold text-blue-700 tracking-wider">
                  {submissionSuccess.rfqId}
                </span>
                <button
                  onClick={copyRefId}
                  className="p-1.5 text-slate-500 hover:text-slate-800 rounded bg-white border border-slate-200 text-xs flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedId ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="mt-2 text-[11px] text-slate-500">
                Proprietor: {COMPANY_PROFILE.proprietor} · GSTIN: {COMPANY_PROFILE.gstin}
              </div>
            </div>

            {/* Instant WhatsApp Redirection & Close */}
            <div className="space-y-3">
              <a
                href={submissionSuccess.waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3.5 px-4 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-500 transition-colors flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20"
              >
                <MessageCircle className="w-5 h-5" />
                <span>Open in WhatsApp for Instant Dispatch Confirmation</span>
              </a>

              <button
                onClick={() => {
                  setSubmissionSuccess(null);
                  onClose();
                }}
                className="w-full py-2.5 px-4 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                Close & Return to Catalog
              </button>
            </div>
          </div>
        ) : (
          /* Submission Form */
          <form onSubmit={handleSubmit} className="p-6 max-h-[80vh] overflow-y-auto space-y-5">
            {formError && (
              <div className="p-3 rounded-lg bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Product Items Selection Section */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Selected Products for Consolidated Quotation ({cartItems.length})
                </label>
                {cartItems.length > 0 && (
                  <button
                    type="button"
                    onClick={onClearCart}
                    className="text-[11px] text-red-600 hover:underline"
                  >
                    Clear All Items
                  </button>
                )}
              </div>

              {cartItems.length > 0 ? (
                <div className="space-y-2 border border-slate-200 rounded-xl p-3 bg-slate-50">
                  {cartItems.map((item) => (
                    <div
                      key={item.product.id}
                      className="bg-white p-3 rounded-lg border border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex-1">
                        <div className="font-bold text-slate-900">{item.product.name}</div>
                        <div className="text-[11px] text-slate-500">
                          {item.product.divisionName} · Standard MOQ: {item.product.standardMoq}
                        </div>
                      </div>

                      <div className="flex items-center gap-2 w-full sm:w-auto">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[11px] text-slate-500">Qty:</span>
                          <input
                            type="text"
                            value={item.quantity}
                            onChange={(e) => onUpdateQuantity(item.product.id, e.target.value)}
                            placeholder="e.g. 5 MT"
                            className="w-28 px-2 py-1 bg-slate-50 border border-slate-300 rounded font-mono text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => onRemoveItem(item.product.id)}
                          className="p-1 text-slate-400 hover:text-red-600 transition-colors"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : initialProduct ? (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <div className="font-bold text-slate-900">{initialProduct.name}</div>
                  <div className="text-[11px] text-slate-500 mb-2">
                    {initialProduct.divisionName} · MOQ: {initialProduct.standardMoq}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-600">Estimated Target Quantity:</span>
                    <input
                      type="text"
                      value={standaloneQuantity}
                      onChange={(e) => setStandaloneQuantity(e.target.value)}
                      placeholder="e.g. 10 MT or 5,000 Boxes"
                      className="flex-1 px-2.5 py-1.5 bg-white border border-slate-300 rounded font-mono text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>
              ) : (
                <div className="p-3.5 bg-blue-50/60 rounded-xl border border-blue-100 text-xs text-slate-700 space-y-2">
                  <p className="text-slate-600">
                    Your RFQ cart is empty. You can specify your desired product or requirements below:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <input
                      type="text"
                      value={standaloneProduct}
                      onChange={(e) => setStandaloneProduct(e.target.value)}
                      placeholder="e.g. Hydrochloric Acid 33% or 5-Ply Cartons"
                      className="px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                    <input
                      type="text"
                      value={standaloneQuantity}
                      onChange={(e) => setStandaloneQuantity(e.target.value)}
                      placeholder="e.g. 20 MT / 10,000 Boxes"
                      className="px-2.5 py-1.5 bg-white border border-slate-300 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Buyer Contact Details Grid */}
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                Buyer & Delivery Information
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Contact Person Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Rajesh Kumar"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Company / Firm Name
                  </label>
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="e.g. Apex Industrial Solutions Ltd"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Phone / Mobile Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="e.g. +91 9876543210"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Business Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    placeholder="e.g. procurement@company.com"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Destination City / State
                  </label>
                  <input
                    type="text"
                    value={deliveryLocation}
                    onChange={(e) => setDeliveryLocation(e.target.value)}
                    placeholder="e.g. Hyderabad, Telangana"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    Postal PIN Code
                  </label>
                  <input
                    type="text"
                    value={pinCode}
                    onChange={(e) => setPinCode(e.target.value)}
                    placeholder="e.g. 500090"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  Custom Technical Specifications / Packaging Remarks
                </label>
                <textarea
                  rows={2}
                  value={customNotes}
                  onChange={(e) => setCustomNotes(e.target.value)}
                  placeholder="Mention desired purity %, fluting type, carton dimensions, test certificate requirements, or delivery schedule..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Modal Bottom CTA */}
            <div className="pt-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-[11px] text-slate-500 text-center sm:text-left">
                Direct statutory dispatch by Vagdevi Industries · GSTIN: 36CBLPG2247K1ZH
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-1/2 sm:w-auto px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-1/2 sm:w-auto px-6 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-50 rounded-lg shadow-sm flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Registering RFQ...' : 'Submit RFQ'}</span>
                </button>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
