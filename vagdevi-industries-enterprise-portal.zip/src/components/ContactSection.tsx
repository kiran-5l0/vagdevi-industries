import React from 'react';
import {
  MapPin,
  Phone,
  Mail,
  Clock,
  Download,
  MessageCircle,
  ShieldCheck,
  Building2,
  ExternalLink,
} from 'lucide-react';
import { COMPANY_PROFILE } from '../data/portalData';

interface ContactSectionProps {
  onOpenBrochure: () => void;
  onOpenRFQ: () => void;
}

export const ContactSection: React.FC<ContactSectionProps> = ({
  onOpenBrochure,
  onOpenRFQ,
}) => {
  return (
    <section id="contact-section" className="py-16 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="text-xs font-semibold text-blue-700 tracking-wider uppercase mb-2">
            Registered Headquarters & Commercial Desk
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight [text-wrap:balance]">
            Connect Directly with Vagdevi Industries
          </h2>
          <p className="mt-3 text-sm text-slate-600 leading-relaxed">
            Reach out to our commercial procurement and logistics coordinators at our registered office in Bachupally, Hyderabad. We provide fast response for rate contracts, tanker bookings, and bulk agro/carton inquiries.
          </p>
        </div>

        {/* Contact Grid & Map */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Details Column */}
          <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col justify-between">
            <div className="space-y-6">
              <div>
                <div className="text-xs font-mono font-semibold text-blue-600 uppercase tracking-wider">
                  Enterprise Profile
                </div>
                <h3 className="text-xl font-bold text-slate-900 mt-1">
                  {COMPANY_PROFILE.tradeName}
                </h3>
                <div className="text-xs text-slate-500 font-mono mt-0.5">
                  Legal Entity: {COMPANY_PROFILE.proprietor}
                </div>
                <div className="mt-1 text-xs font-mono text-emerald-700 font-semibold">
                  GSTIN: {COMPANY_PROFILE.gstin}
                </div>
              </div>

              {/* Address */}
              <div className="flex items-start gap-3 text-xs">
                <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900 mb-0.5">Registered Office:</div>
                  <address className="not-italic text-slate-600 leading-relaxed">
                    {COMPANY_PROFILE.registeredAddress}
                  </address>
                </div>
              </div>

              {/* Phone Numbers */}
              <div className="flex items-start gap-3 text-xs">
                <Phone className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900 mb-0.5">Sales Hotlines:</div>
                  <div className="space-y-1">
                    <div>
                      <a
                        href={`tel:${COMPANY_PROFILE.primaryPhoneRaw}`}
                        className="text-blue-600 hover:underline font-mono font-semibold"
                      >
                        {COMPANY_PROFILE.primaryPhone}
                      </a>{' '}
                      <span className="text-slate-400">(Primary Sales & Tanker Booking)</span>
                    </div>
                    <div>
                      <a
                        href={`tel:${COMPANY_PROFILE.secondaryPhoneRaw}`}
                        className="text-blue-600 hover:underline font-mono"
                      >
                        {COMPANY_PROFILE.secondaryPhone}
                      </a>{' '}
                      <span className="text-slate-400">(Secondary / Packaging Desk)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Email */}
              <div className="flex items-start gap-3 text-xs">
                <Mail className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900 mb-0.5">Official RFQ & Tender Email:</div>
                  <a
                    href={`mailto:${COMPANY_PROFILE.salesEmail}`}
                    className="text-blue-600 hover:underline font-mono font-semibold"
                  >
                    {COMPANY_PROFILE.salesEmail}
                  </a>
                </div>
              </div>

              {/* Operating Hours & Dispatch */}
              <div className="flex items-start gap-3 text-xs">
                <Clock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold text-slate-900 mb-0.5">Operating & Dispatch Schedule:</div>
                  <div className="text-slate-600">{COMPANY_PROFILE.dispatchHours}</div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{COMPANY_PROFILE.logisticsReach}</div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row gap-3">
              <button
                onClick={onOpenBrochure}
                className="w-full sm:w-1/2 py-2.5 px-4 text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-600" />
                <span>Unified Catalog PDF</span>
              </button>

              <a
                href={COMPANY_PROFILE.whatsAppLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-1/2 py-2.5 px-4 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>WhatsApp Sales Desk</span>
              </a>
            </div>
          </div>

          {/* Interactive Google Map & Location Embed Frame */}
          <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
            <div className="p-4 bg-slate-100/70 border-b border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs">
                <MapPin className="w-4 h-4 text-red-500" />
                <span className="font-bold text-slate-800">
                  Bachupally, Hyderabad Logistics Hub (PIN: 500090)
                </span>
              </div>
              <a
                href="https://maps.google.com/?q=Bachupally,+Hyderabad,+Telangana+500090"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-medium text-blue-600 hover:underline flex items-center gap-1"
              >
                <span>Open in Google Maps</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* Embedded Responsive Google Map */}
            <div className="relative flex-1 min-h-[360px] bg-slate-100">
              <iframe
                title="Vagdevi Industries Location - Bachupally Hyderabad"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3804.095431602127!2d78.36881267493863!3d17.550186783363365!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb8f000b2184d3%3A0x6bbf510a76a5a04e!2sBachupally%2C%20Hyderabad%2C%20Telangana%20500090!5e0!3m2!1sen!2sin!4v1700000000000!5m2!1sen!2sin"
                className="w-full h-full border-0 absolute inset-0"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>

            {/* Map Caption */}
            <div className="p-3.5 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-600 flex flex-wrap items-center justify-between gap-2">
              <span>Road No. 7, Kolan Rama Chandra Reddy Nagar Colony, Bachupally</span>
              <span className="font-mono text-slate-500">Coordinates: 17.5502° N, 78.3688° E</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
