import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface RFQItem {
  productId: string;
  productName: string;
  divisionId: string;
  quantity: string;
  targetSpecs?: string;
}

interface RFQPayload {
  name: string;
  company?: string;
  phone: string;
  email: string;
  location?: string;
  pincode?: string;
  division?: string;
  divisions?: string[];
  items?: RFQItem[];
  singleProduct?: string;
  singleQuantity?: string;
  message?: string;
}

async function startServer() {
  const app = express();
  const port = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json());

  // In-memory quote registry for recent submissions
  const quoteSubmissions: Array<{
    id: string;
    receivedAt: string;
    payload: RFQPayload;
  }> = [];

  // API Route: Submit Request For Quote (RFQ)
  app.post('/api/rfq', (req, res) => {
    try {
      const body: RFQPayload = req.body;
      const { name, phone, email } = body;

      if (!name || !phone || !email) {
        return res.status(400).json({
          success: false,
          error: 'Please provide full name, contact phone number, and official email address.',
        });
      }

      // Generate enterprise tracking ID: RFQ-VGD-YYYYMMDD-XXXX
      const datePart = new Date().toISOString().slice(0, 10).replace(/-/g, '');
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const rfqId = `RFQ-VGD-${datePart}-${randomSuffix}`;

      quoteSubmissions.unshift({
        id: rfqId,
        receivedAt: new Date().toISOString(),
        payload: body,
      });

      // Keep max 100 entries in memory
      if (quoteSubmissions.length > 100) {
        quoteSubmissions.pop();
      }

      console.log(`[VAGDEVI RFQ NOTIFICATION] New Inquiry Reference: ${rfqId}`);
      console.log(`To: salesh.vagdevi6@gmail.com`);
      console.log(`From: ${name} | Company: ${body.company || 'Not Specified'} | Phone: ${phone} | Email: ${email}`);
      console.log(`Delivery Destination: ${body.location || 'Pan-India'} (${body.pincode || 'N/A'})`);
      console.log(`Items/Scope:`, body.items || body.singleProduct || 'General conglomerate quotation');

      return res.status(200).json({
        success: true,
        rfqId,
        forwardedTo: 'salesh.vagdevi6@gmail.com',
        receivedAt: new Date().toISOString(),
        message: 'Your Request For Quote has been formally registered with Vagdevi Industries. Our industrial sales team will review your specifications and contact you with commercial terms within 2 hours.',
      });
    } catch (err: any) {
      console.error('Error handling RFQ submission:', err);
      return res.status(500).json({
        success: false,
        error: 'Internal server error while logging quote request.',
      });
    }
  });

  // API Route: Health & Statutory verification endpoint
  app.get('/api/enterprise-profile', (_req, res) => {
    res.json({
      name: 'Vagdevi Industries',
      proprietor: 'Gorli Satyavathi',
      gstin: '36CBLPG2247K1ZH',
      address: 'Flat No. 302, Sai Homes, Road No. 7, Kolan Rama Chandra Reddy Nagar Colony, Bachupally, Hyderabad, Rangareddy, Telangana - 500090, India',
      contacts: {
        primaryPhone: '+91 8639638288',
        secondaryPhone: '+91 9000345708',
        email: 'salesh.vagdevi6@gmail.com',
        whatsapp: 'https://wa.me/918639638288',
      },
      divisions: [
        'Industrial Chemicals & Acids',
        'Dehydrated Vegetables, Fruits & Flakes',
        'Premium Dry Fruits & Nuts',
        'Packaging & Corrugated Boxes',
      ],
    });
  });

  // Client static assets in production, Vite middleware in dev
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`[VAGDEVI INDUSTRIES] Server initialized at http://0.0.0.0:${port}`);
  });
}

startServer();
